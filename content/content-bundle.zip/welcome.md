---
home: true
---

![](https://source.unsplash.com/hpjihlapEXg/1900x1200)

## Welcome

I'm Nicola and this is my Digital Garden - you're reading my published Obsidian notes. Some of these are works in progress, some merely ideas or headlines, others may have been published elsewhere. Some notes, and my thinking, may be incomplete.

The range of topics reflects my eclectic fascinations from tech, writing, to the esoteric. 

---
Copyright © 2022 Nicola Fisher