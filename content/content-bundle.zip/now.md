![](https://source.unsplash.com/8B925jkxa7M/1900x1200)

## Now

What I'm doing now ... 

## Shifting

As my writing becomes my side hustle for a while, I find myself evolving in new directions. 

I fell out of love with Instagram and have recently turned my account into a personal, friends and family only, private space. Already it feels much better.

While my writing time will be much reduced I'm pondering how I can continue to create on a pared down schedule. 

## Writing

I'm going back to basics and prioritising my book. Inspired by Nicole Gulotta, I've reworked my website and the layout of Live Life Gently - Change the World. Nicole talks about Writing Seasons and, while a different premise to The Essence Map, made me realise I could rework the map milestones.

## Recording

I still love audio and am pondering how I can record more regularly.

Both Twitter and Substack have useful audio options and I may use one or both of those.

## Tweeting

I'm not much on Instagram these days. Twitter is more vibrant right now. I'm loving the new Twitter Circle function and am experimenting with that. Just waiting for Notes to be added to my account.

## Consolidating

I still love the tiny web and want to find a way to have everything in one place. I may or may not achieve that. 

My website has been simplified and I'm using Markbase for my digital garden.

## Reading

<iframe width="100%" height="560" src="https://glasp.co/embed?u=XAggf0t62RV5j9p0Ke8I4OFwT1n2&n=4" title="Glasp Profile Embed" frameborder="0"></iframe>

---

*Part of [this](https://nownownow.com/about). Create [your own page](https://nownownow.com/about).*

*Last update: 2022-08-22*

---
Copyright © 2022 Nicola Fisher