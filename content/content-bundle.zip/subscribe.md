![](https://source.unsplash.com/u99M_BVwJ9o/1900x1200)

## Subscribe

I publish three different newsletters. 

---

## 1. Nicola Fisher Writer

I write on Substack and send out [a monthly newsletter.](https://nicolafisherwriter.substack.com/)

<iframe src="https://nicolafisherwriter.substack.com/embed" width="480" height="320" style="border:1px solid #EEE; background:white;" frameborder="0" scrolling="no"></iframe>

---

## 2. Finding Flow

[Finding Flow](https://findingflow.substack.com/) is published on an almost daily schedule.

<iframe src="https://findingflow.substack.com/embed" width="480" height="320" style="border:1px solid #EEE; background:white;" frameborder="0" scrolling="no"></iframe>

---

## 3. Books Beans Boots

I'm compile a very simple weekly update - what I'm reading, coffee and cafés, the places I go. [Subscribe here](https://www.getrevue.co/profile/booksbeansboots).

---
Copyright © 2022 Nicola Fisher