![](https://source.unsplash.com/r49MK_VzMU0/1900x1200)

## About Me

I'm Nicola. A Writer, Photographer, Podcaster, Geek.

I live in a small village in the Peak Park area of Derbyshire with my husband, [Chris](https://theblindwoodturner.co.uk/), and his Guide Dog, Bamber.

I’m an INFP. I’m unconventional, quirky, an introvert and live outside the circle. That might make me eccentric!

I have an eclectic range of interests. 

## Writing

I write about the intersection between tech and living at a gentler pace. I'm exploring the premise that, if more of us lived a gentle life, reconnected to who we truly are, or our essence, as I call it, we could change the world for the better.

---
Copyright © 2022 Nicola Fisher